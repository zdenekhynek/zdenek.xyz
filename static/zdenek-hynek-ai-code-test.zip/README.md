# TV MAZE CODING TEST

## The Task

The goal of this exercise is to produce a production ready, Single Page Application that
allows you to find and display your favourite tv shows using the free and open API
by tvmaze (http://www.tvmaze.com/api). We recommend React as we use it extensively at
Signal, but feel free to use whatever you're comfortable with.

There are two files included (list-mockup.png and details-mockup.png) that show 2 states
we'd like to have in the final application.

1. The first state allows you to search over tvshows. The results are shown in a 3 column poster layout that shows the poster, title and genres for each TV show.

2. The details view shows more metadata about the TV show, including description, cast and season information. Finally, it gives the option to star (locally persist) the TV show for viewing later.

Please submit your solution as a zip file.

We know you're busy, so try not to spend more than 3 to 4 hours on this exercise.

## Requirements

- Node `12`
- npm `6`

## Setup

Install node dependencies:

`npm i`

## Development

### `npm start`

Runs the app in the development mode.<br />
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br />
You will also see any lint errors in the console.

### `npm test`

Launches the test runner in the interactive watch mode.<br />
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `npm run build`

Builds the app for production to the `build` folder.<br />
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.<br />
Your app is ready to be deployed!

## Deployment

The app is deployed with Netlify with Github integration. When the master branch is updated in the remote origin,
Netlify runs `npm build` and deploys the production version of the app compiled in the `/build` folder.

Staging url: `https://heuristic-edison-b8fa61.netlify.app/`

## Code style

Code style is based on Create React app extended with Airbnb styleguide. Code is linted on every commit
with [Husky](https://github.com/typicode/husky) and [Lint Staged](https://github.com/okonet/lint-staged) following the setup described [here](https://medium.com/@pppped/extend-create-react-app-with-airbnbs-eslint-config-prettier-flow-and-react-testing-library-96627e9a9672).

## TODO

- introducing React.Context or Redux for properly fetching and storing data
- better responsiveness
- proper unit-tests
- deep-linking
- animations
- CSS cleanup
