export const BASE_URL = "https://api.tvmaze.com/shows";
export const BASE_SEARCH_URL = "https://api.tvmaze.com/search/shows";

export const constructFetchUrl = (searchQuery = "") => {
  return searchQuery ? `${BASE_SEARCH_URL}?q=${searchQuery}` : BASE_URL;
};

export const parseResponse = (shows) => {
  //  convert the search results
  return shows.map((s) => {
    return s.show;
  });
};

export const constructSingleShowFetchUrl = (showId) => {
  return `${BASE_URL}/${showId}?embed[]=cast&embed[]=seasons`;
};

export const fetchSingleShow = (showId) => {
  return new Promise((resolve, reject) => {
    const url = constructSingleShowFetchUrl(showId);

    fetch(url)
      .then((resp) => resp.json())
      .then(resolve)
      .catch(() => {
        reject(new Error("Error fetching movie shows."));
      });
  });
};

export default (searchQuery = "") => {
  return new Promise((resolve, reject) => {
    const url = constructFetchUrl(searchQuery);

    fetch(url)
      .then((resp) => resp.json())
      .then((shows) => {
        if (!searchQuery) {
          return shows;
        }

        return parseResponse(shows);
      })
      .then(resolve)
      .catch(() => {
        reject(new Error("Error fetching movie shows."));
      });
  });
};
