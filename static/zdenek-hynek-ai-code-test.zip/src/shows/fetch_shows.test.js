import fetchShows, { fetchSingleShow } from "./fetch_shows";

describe("Fetch shows", () => {
  beforeAll(() => {
    //  setup mock
    global.fetch = jest.fn(() =>
      Promise.resolve({
        json: () =>
          Promise.resolve([
            { a: 1, b: 2 },
            { c: 3, d: 4 },
          ]),
      })
    );
  });

  beforeEach(() => {
    global.fetch.mockClear();
  });

  it("fetches single show", async () => {
    const fetchSpy = jest.spyOn(global, "fetch");
    await fetchSingleShow(1);
    expect(fetchSpy).toBeCalled();
    expect(fetchSpy).toBeCalledWith(
      "https://api.tvmaze.com/shows/1?embed[]=cast&embed[]=seasons"
    );
  });

  it("fetches search shows", async () => {
    const fetchSpy = jest.spyOn(global, "fetch");
    const shows = await fetchShows("bojack");
    expect(fetchSpy).toBeCalled();
    expect(fetchSpy).toBeCalledWith(
      "https://api.tvmaze.com/search/shows?q=bojack"
    );
    expect(shows.length).toEqual(2);
  });

  afterAll(() => {
    //  make sure to restore original fetch
    //  in case some other test suite relied on it
    //  unlikely, but hey
    global.fetch.mockRestore();
  });
});
