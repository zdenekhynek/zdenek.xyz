export const LOCAL_STORAGE_KEY = "tv-maze-coding-test-show-likes";

export const setShowLikes = (showLikes) => {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(showLikes));
  } catch (err) {
    console.error(err);
  }
};

export const getShowLikes = () => {
  const serializedLikes = localStorage.getItem(LOCAL_STORAGE_KEY);

  if (!serializedLikes) {
    return [];
  }

  try {
    return JSON.parse(serializedLikes);
  } catch (err) {
    console.error(err);
    return [];
  }
};

export const saveShowLike = (showId) => {
  const showLikes = getShowLikes(showId);
  showLikes.push(showId);

  //  make sure we don't store like to the same show twice
  const uniqueLikes = [...new Set(showLikes)];
  setShowLikes(uniqueLikes);
};

export const unsaveShowLike = (showId) => {
  const showLikes = getShowLikes(showId);
  const newShowLikes = showLikes.filter((show) => show !== showId);
  setShowLikes(newShowLikes);
};

export const isShowLiked = (showId) => {
  const likes = getShowLikes();
  return likes.includes(showId);
};
