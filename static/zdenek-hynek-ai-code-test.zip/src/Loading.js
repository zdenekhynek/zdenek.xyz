import React from "react";
import PropTypes from "prop-types";

export default function Loading({ msg }) {
  return <div>{msg}</div>;
}

Loading.propTypes = {
  msg: PropTypes.string,
};

Loading.defaultProps = {
  msg: "Loading...",
};
