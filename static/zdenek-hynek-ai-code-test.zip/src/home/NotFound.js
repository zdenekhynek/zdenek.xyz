import React from "react";

import "./NotFound.css";

export default function NotFound() {
  return (
    <div className="not-found">
      <span>:(</span> We haven&apos;t found any shows, please try searching for a
      different show.
    </div>
  );
}

NotFound.propTypes = {};

NotFound.defaultProps = {};
