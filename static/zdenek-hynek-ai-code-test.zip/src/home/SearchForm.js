import React from "react";
import PropTypes from "prop-types";

import "./SearchForm.css";

export default function SearchForm({ onSearch }) {
  const handleSubmit = (evt) => {
    evt.preventDefault();

    const { value } = evt.target.search;
    onSearch(value);
  };

  return (
    <form className="search-form" onSubmit={handleSubmit}>
      <input
        className="search-form__input"
        placeholder="Search for your favorite show"
        name="search"
        type="text"
      />
      <button type="submit" className="search-form__btn">
        <svg width="16" height="17" xmlns="http://www.w3.org/2000/svg">
          <path
            d="M16 15.835l-3.794-3.967c2.273-2.838 2.136-7.084-.412-9.75C10.49.753 8.754 0 6.907 0c-1.845 0-3.58.752-4.886 2.118-2.695 2.82-2.694 7.405 0 10.224 1.305 1.365 3.04 2.117 4.885 2.117a6.657 6.657 0 0 0 4.16-1.456L14.885 17 16 15.835zM3.135 11.177c-2.08-2.177-2.08-5.718 0-7.895C4.143 2.228 5.483 1.648 6.91 1.648c1.426 0 2.765.58 3.773 1.635 2.08 2.176 2.08 5.717 0 7.894-1.008 1.054-2.347 1.635-3.773 1.635-1.426 0-2.766-.58-3.774-1.635z"
          />
        </svg>
      </button>
    </form>
  );
}

SearchForm.propTypes = {
  onSearch: PropTypes.func,
};

SearchForm.defaultProps = {
  onSearch: () => {},
};
