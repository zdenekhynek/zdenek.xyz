import React from "react";

import "./EmptyState.css";

export default function EmptyState() {
  return <div className="empty-state">Signal AI code test by Zdenek Hynek</div>;
}

EmptyState.propTypes = {};

EmptyState.defaultProps = {};
