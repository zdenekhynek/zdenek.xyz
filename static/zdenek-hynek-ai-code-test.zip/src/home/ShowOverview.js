import React from "react";
import PropTypes from "prop-types";

import "./ShowOverview.css";

export const renderImage = (image) => {
  if (!image || !image.medium) {
    //  render empty placeholder
    return <div className="show-overview__image" />;
  }

  const backgroundImage = `url(${image.medium})`;
  return (
    <div className="show-overview__image" style={{ backgroundImage }} />
  );
};

export default function ShowOverview({ id, name, genres, image }) {
  return (
    <a className="show-overview" href={`show/${id}`}>
      {renderImage(image)}
      <div className="show-overview__description">
        <h3 className="show-overview__name">{name}</h3>
        <h4 className="show-overview__genres">{genres.join(", ")}</h4>
      </div>
    </a>
  );
}

ShowOverview.propTypes = {
  id: PropTypes.number,
  name: PropTypes.string,
  genres: PropTypes.arrayOf(PropTypes.string),
  image: PropTypes.shape({
    medium: PropTypes.string,
  }),
};

ShowOverview.defaultProps = {
  id: -1,
  name: "",
  genres: [],
  image: null,
};
