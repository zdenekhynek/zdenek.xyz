import React from "react";
import { mount } from "enzyme";

import Home from "./Home";
import SearchForm from "./SearchForm";

describe("Home", () => {
  let wrapper;

  beforeAll(() => {
    //  setup mock
    global.fetch = jest.fn(() =>
      Promise.resolve({
        json: () =>
          Promise.resolve([
            { id: 1, b: 2 },
            { id: 2, d: 4 },
          ]),
      })
    );
  });

  beforeEach(() => {
    wrapper = mount(<Home />);
  });

  it("renders without crashing", () => {
    expect(wrapper.find(SearchForm).length).toEqual(1);
    expect(wrapper.find("input[type='text']").length).toEqual(1);
  });
});
