import React, { useState } from "react";

import fetchShows from "../shows/fetch_shows";
import Loading from "../Loading";
import Error from "../Error";
import EmptyState from "./EmptyState";
import NotFound from "./NotFound";
import SearchForm from "./SearchForm";
import Shows from "./Shows";

import "./Home.css";

function Home() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [hasEmptyResult, setHasEmptyResult] = useState(false);
  const [shows, setShows] = useState([]);

  //  fetching shows only based on
  const handleSearch = async (searchQuery) => {
    //  flip loading flag to display loading indicator
    setIsLoading(true);

    try {
      const newShows = await fetchShows(searchQuery);
      setShows(newShows);

      //  if we found no shows, we want to display an indicator
      const newHasEmptyResult = newShows.length === 0;
      setHasEmptyResult(newHasEmptyResult);

      //  clear any errors we might have had
      setError(null);
    } catch (err) {
      setError(err.toString());
    }

    //  hide loading indicator
    setIsLoading(false);
  };

  return (
    <div className="home">
      <div className="home__announcements">
        {error && <Error msg={error} />}
        {hasEmptyResult && <NotFound />}
        {!hasEmptyResult && shows.length === 0 && <EmptyState />}
      </div>
      <div className="home__content">
        <header className="home__header">
          <div className="container">
            <SearchForm onSearch={handleSearch} />
          </div>
        </header>
        <div className="container">
          {isLoading && <Loading />}
          {shows.length > 0 && <Shows shows={shows} />}
        </div>
      </div>
    </div>
  );
}

Home.propTypes = {};

Home.defaultProps = {};

export default Home;
