import React from "react";
import PropTypes from "prop-types";
import ShowOverview from "./ShowOverview";

import "./Shows.css";

export default function Shows({ shows }) {
  return (
    <ul className="shows">
      {shows.map((show) => {
        return (
          <li key={show.id}>
            <ShowOverview {...show} />
          </li>
        );
      })}
    </ul>
  );
}

Shows.propTypes = {
  shows: PropTypes.arrayOf(PropTypes.object),
};

Shows.defaultProps = {
  shows: [],
};
