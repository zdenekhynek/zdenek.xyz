import React from "react";
import PropTypes from "prop-types";

import "./Error.css";

export default function Error({ msg }) {
  return <div className="error">{msg}</div>;
}

Error.propTypes = {
  msg: PropTypes.string,
};

Error.defaultProps = {
  msg: "There was an error, please try again.",
};
