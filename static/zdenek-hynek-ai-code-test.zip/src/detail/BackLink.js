import React from 'react'
import { Link } from "react-router-dom";

import "./BackLink.css";

export default function BackLink() {
  return (
    <Link className="back-link" to="/">Back</Link>
  )
}
