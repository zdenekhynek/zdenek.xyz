import React from "react";
import { shallow } from "enzyme";
import { useParams } from "react-router-dom";

import Detail from "./Detail";

describe("Detail", () => {
  it("renders without crashing", () => {
    useParams.mockReturnValue({ id: 1 });

    shallow(<Detail />);
  });
});
