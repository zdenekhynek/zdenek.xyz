import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import { fetchSingleShow } from "../shows/fetch_shows";
import CastProfile from "./CastProfile";
import Season from "./Season";
import {
  isShowLiked,
  saveShowLike,
  unsaveShowLike,
} from "../shows/local_storage";
import Loading from "../Loading";
import Error from "../Error";

import "./Detail.css";
import LikeButton from "./LikeButton";
import BackLink from "./BackLink";

export const renderCast = (cast) => {
  return (
    <div className="detail__list">
      <h3 className="detail__list__title">Cast</h3>
      <ul className="detail__list__ul">
        {cast.map(({ person }) => {
          return (
            <li key={person.id}>
              <CastProfile {...person} />
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export const renderSeasons = (seasons) => {
  return (
    <div className="detail__list">
      <h3 className="detail__list__title">Seasons</h3>
      <ul className="detail__list__ul">
        {seasons.map((season) => {
          return (
            <li key={season.id}>
              <Season {...season} />
            </li>
          );
        })}
      </ul>
    </div>
  );
};

function ShowDetail() {
  const { id } = useParams();
  const [error, setError] = useState(null);
  const [show, setShow] = useState(null);
  const [isLiked, setIsLiked] = useState(() => {
    //  get initial state and see if show
    //  has been previously liked
    return isShowLiked(id);
  });

  // initial fetch of show details
  useEffect(() => {
    (async () => {
      try {
        const newShow = await fetchSingleShow(id);
        setShow(newShow);
      } catch (err) {
        setError(err.toString());
      }
    })();
  }, [id]);

  const handleLike = () => {
    //  toggle flag
    setIsLiked(!isLiked);

    //  persist to local storage
    if (!isLiked) {
      saveShowLike(id);
    } else {
      unsaveShowLike(id);
    }
  };

  if (error) {
    return <Error msg={error} />;
  }

  if (!show) {
    return <Loading msg="Loading show detail..." />;
  }

  const { name, summary, image, _embedded: embedded } = show;

  return (
    <div className="detail container">
      <div className="detail__back">
        <BackLink />
      </div>
      <header className="detail__header">
        {image && image.original && (
          <img
            className="detail__header__image"
            src={image.original}
            alt={name}
          />
        )}
        {name && <h2 className="detail_title">{name}</h2>}
        <LikeButton isLiked={isLiked} onLike={handleLike} />
      </header>
      {summary && (
        <h3
          className="detail__summary"
          dangerouslySetInnerHTML={{ __html: summary }}
        />
      )}

      {embedded && embedded.cast && renderCast(embedded.cast)}
      {embedded && embedded.seasons && renderSeasons(embedded.seasons)}
    </div>
  );
}

ShowDetail.propTypes = {};

ShowDetail.defaultProps = {};

export default ShowDetail;
