import React from "react";
import PropTypes from "prop-types";

import "./CastProfile.css";


export const renderImage = (image) => {
  if (!image || !image.medium) {
    //  render empty placeholder
    return <div className="cast-profile__image" />;
  }

  const backgroundImage = `url(${image.medium})`;
  return (
    <div className="cast-profile__image" style={{ backgroundImage }} />
  );
};

export default function CastProfile({ url, image, name }) {
  return (
    <a
      className="cast-profile"
      href={url}
      target="_blank"
      rel="noopener noreferrer"
    >
      {renderImage(image)}
      <h4 className="cast-profile__name">{name}</h4>
    </a>
  );
}

CastProfile.propTypes = {
  url: PropTypes.string,
  name: PropTypes.string,
  image: PropTypes.shape({
    medium: PropTypes.string,
  }),
};

CastProfile.defaultProps = {
  url: "",
  name: "",
  image: null,
};
