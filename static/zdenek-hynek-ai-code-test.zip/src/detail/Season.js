import React from "react";
import PropTypes from "prop-types";

import { renderImage } from "./CastProfile";

export default function Season({ url, number, image }) {
  const seasonName = `Season ${number}`;

  return (
    <a
      className="cast-profile"
      href={url}
      target="_blank"
      rel="noopener noreferrer"
    >
      {renderImage(image)}
      <h4 className="cast-profile__name">{seasonName}</h4>
    </a>
  );
}

Season.propTypes = {
  number: PropTypes.number,
  image: PropTypes.shape({
    medium: PropTypes.string,
  }),
  url: PropTypes.string,
};

Season.defaultProps = {
  number: -1,
  image: null,
  url: "",
};
